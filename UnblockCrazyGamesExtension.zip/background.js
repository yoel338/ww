chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    return {cancel: false};
  },
  {urls: ["https://www.crazygames.com/*"]},
  ["blocking"]
);
