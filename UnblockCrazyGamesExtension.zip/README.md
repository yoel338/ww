# Unblock Crazy Games Extension

An extension that unblocks https://www.crazygames.com/.

## How to Install

1. Download this code to your machine.

2. Open Google Chrome and go to `chrome://extensions`.

3. Enable Developer mode by toggling the switch in the top-right corner.

4. Click on "Load unpacked" button and select the "UnblockCrazyGamesExtension" folder.

5. The extension should now appear in your extensions list and be ready for use.

## How to Use

Once the extension is installed, it will automatically unblock https://www.crazygames.com/. You can now access the website without any restrictions.

## How to Test

To test the extension locally, follow the "How to Install" instructions above. Once installed, try accessing https://www.crazygames.com/ and verify that it is no longer blocked.

## How to Develop

1. Make changes to the extension files as needed.

2. To see the changes, go to `chrome://extensions` and click on the "Refresh" button for the Unblock Crazy Games Extension.

3. Test the changes by accessing https://www.crazygames.com/ and ensuring it is still unblocked.

## How to Distribute

To distribute the extension, you need to package it as a .crx file. This can be done through the Chrome Web Store developer dashboard. Refer to the [official Chrome extension distribution guide](https://developer.chrome.com/docs/extensions/mv3/hosting/) for more details.

## Next Steps

Here are some possible next steps to improve the extension:

- Add options to unblock other websites.
- Implement a whitelist or blacklist functionality to selectively unblock websites.
- Add a user interface to manage the extension settings.
